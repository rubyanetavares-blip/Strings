const botaoMonstraPalavras = document.querySelector( '#botao-palavrachave')

botaoMonstraPalavras.addEventListener('click', mostraPalavraChave);

function mostraPalavraChave () {
    const texto = document.querySelector('#entrada-de-texto').volue;
    const campoResultado = document.querySelector('#resultado-palavrachave');

    campoResultado
}